import random

import pgzrun

WIDTH=350
HEIGHT=600

background=Actor('background')
bird=Actor('bird')
bird.x=50
bird.y=300
bar_up=Actor('bar_up')
bar_up.x=300
bar_up.y=0
bar_down=Actor('bar_down')
bar_down.x=300
bar_down.y=600
lost=False
speed_up=False
score=0
speed=2
def on_mouse_down():
    bird.y =bird.y-100
def update():
    global score
    global lost
    global speed
    global speed_up
    if lost==False:
        bird.y=bird.y+2
        bar_up.x-=speed
        bar_down.x-=speed
    if bar_up.x<0:
        score+=1
        bar_down.x=WIDTH
        bar_up.x=WIDTH
        bar_up.y=random.randint(-100,100)
        bar_down.y=bar_up.y+600
    if score%5==0 and score!=0 and speed_up==False:
        speed+=1
        speed_up=True
    elif score%5!=0:
        speed_up=False
def draw():
    global lost
    if bird.colliderect(bar_up) or bird.colliderect(bar_down):
        lost=True

    background.draw()
    bird.draw()
    bar_down.draw()
    bar_up.draw()
    screen.draw.text(str(score), (30, 30),fontsize=50, color='green')
    if lost==True:
        screen.draw.text('LOST', center=[150, 300], fontsize=60)
pgzrun.go()