import pgzrun  # 导入游戏库
WIDTH = 640   # 设置窗口的宽度
HEIGHT = 480   # 设置窗口的高度

# 导入所有的分解动作图片，存在列表当中
GD=[Actor('gd0'), Actor('gd1'), Actor('gd2'),Actor('gd3'), Actor('gd4'),Actor('gd5'),Actor('gd6'),Actor('gd7')]
GL=[Actor('gl0'), Actor('gl1'), Actor('gl2'),Actor('gl3'), Actor('gl4'),Actor('gl5'),Actor('gl6'),Actor('gl7')]
GR=[Actor('gr0'), Actor('gr1'), Actor('gr2'),Actor('gr3'), Actor('gr4'),Actor('gr5'),Actor('gr6'),Actor('gr7')]
GU=[Actor('gu0'), Actor('gu1'), Actor('gu2'),Actor('gu3'), Actor('gu4'),Actor('gu5'),Actor('gu6'),Actor('gu7')]
Anims = [Actor('1'), Actor('2'), Actor('3'),
         Actor('4'), Actor('5')]
background=Actor('bg')
numAnims = len(GD)  # 分解动作图片的张数
animIndex = 0  # 表示需要显示的动作图片的序号
animSpeed = 0 # 用于控制行走动画速度
direct=0
player_x = WIDTH/2  # 设置玩家的x坐标
player_y = HEIGHT/2   # 设置玩家的y坐标
for i in range(numAnims):
    GR[i].x = player_x  # 设置所有分解动作图片的x坐标
    GR[i].y = player_y  # 设置所有分解动作图片的y坐标
    GL[i].x = player_x  # 设置所有分解动作图片的x坐标
    GL[i].y = player_y  # 设置所有分解动作图片的y坐标
    GU[i].x = player_x  # 设置所有分解动作图片的x坐标
    GU[i].y = player_y  # 设置所有分解动作图片的y坐标
    GD[i].x = player_x  # 设置所有分解动作图片的x坐标
    GD[i].y = player_y  # 设置所有分解动作图片的y坐标

def draw():    # 绘制模块，每帧重复执
    global direct
    background.draw()
    if direct==0:
        GR[animIndex].draw()  # 绘制玩家当前分解动作图片
    if direct==1:
        GL[animIndex].draw()  # 绘制玩家当前分解动作图片
    if direct==2:
        GU[animIndex].draw()  # 绘制玩家当前分解动作图片
    if direct==3:
        GD[animIndex].draw()  # 绘制玩家当前分解动作图片

def update():  # 更新模块，每帧重复操作
    global animIndex, player_x, animSpeed,player_y,direct
    mov = False
    if keyboard.right:  # 如果按下键盘右键
        player_x += 5  # 角色向右移动
        for i in range(numAnims):  # 所有分解动作图片更新x坐标
            GD[i].x = player_x
            GL[i].x=player_x
            GR[i].x=player_x
            GU[i].x=player_x
        mov=True
        direct=0
    if keyboard.left:  # 如果按下键盘右键
        player_x -= 5  # 角色向右移动
        for i in range(numAnims):  # 所有分解动作图片更新x坐标
            GD[i].x = player_x
            GL[i].x=player_x
            GR[i].x=player_x
            GU[i].x=player_x
        mov=True
        direct=1
    if keyboard.up:  # 如果按下键盘右键
        player_y -= 5  # 角色向右移动
        for i in range(numAnims):  # 所有分解动作图片更新x坐标
            GD[i].y = player_y
            GL[i].y=player_y
            GR[i].y=player_y
            GU[i].y=player_y
        mov=True
        direct=2
    if keyboard.down:  # 如果按下键盘右键
        player_y += 5  # 角色向右移动
        for i in range(numAnims):  # 所有分解动作图片更新x坐标
            GD[i].y = player_y
            GL[i].y=player_y
            GR[i].y=player_y
            GU[i].y=player_y
        mov=True
        direct=3
    if (player_x >= WIDTH):  # 角色走到最右边
                player_x = 0  # 再从最左边出现
    if mov==True:
        animSpeed += 1 # 用于控制动作动画速度
        if animSpeed % 5 == 0:  # 动作动画速度是移动速度的1/5
            animIndex += 1  # 每一帧分解动作图片序号加1
        if animIndex >= numAnims:  # 放完最后一个分解动作图片了
            animIndex = 0  # 再变成第一张分解动作图片        

pgzrun.go()  # 开始执行游戏