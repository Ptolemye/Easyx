﻿
#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"
#include<time.h>
#include <list>
//#define WIDTH  640
//#define HEIGHT 480

#define WIDTH  787
#define HEIGHT 590
using namespace std;
class Snow
{
public:
	IMAGE im_snow;
	float x=rand()%787, y = 0;
	float r=10;
	float speed = 2 + rand() % 3;
	Snow()
	{
		loadimage(&im_snow, _T("snow.png"));
	}
	void draw()
	{
		putimagePng(x - r, y - r, &im_snow);
	}
	void update()
	{
		if (rand() % 2 == 0)
			x += 3;
		else
			x -= 3;
		y += speed;
		if (y > 590)
		{
			x = rand() % 787;
			y = 0;
			speed = 2 + rand() % 3;
		}
	}
};
list<Snow>Snows;
int dx, speed;
int snowcount = 15;
int main()
{
	srand((unsigned int)time(NULL));
	IMAGE im_bk;
	loadimage(&im_bk, _T("bg.png"));
	initgraph(WIDTH, HEIGHT);
	DWORD t1, t2;
	t1 = GetTickCount();
	speed = 3;
	BeginBatchDraw();
	while (1)
	{
		putimage(0, 0, &im_bk);
		if (snowcount > 0) {
			t2 = GetTickCount();
			if (t2 - t1 >= 1000) {
				Snows.push_back(Snow());
				t2 = t1;
				snowcount--;
			}
		}
		for (auto& p : Snows) {
			p.update();
			p.draw();
		}
		Sleep(10);
		FlushBatchDraw();
		dx += speed;
		if (dx >= WIDTH)
			dx = speed;
	}
	_getch();
	return 0;
}

