﻿
#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"

#define WIDTH  640
#define HEIGHT 480

int speed = -6;
int x = WIDTH-100;

int main()
{
	IMAGE im_bk, im_dra;
	initgraph(WIDTH, HEIGHT);
	int direct = 0;//0向左，1向右
	int i = 0;
	TCHAR filename[20];
	IMAGE img[8];

	for (i = 0; i < 8; i++)
	{
		_stprintf_s(filename, _T("g%d.png"), i);
		loadimage(&img[i], filename);
	}

	loadimage(&im_bk, _T("bg.png"));

	i = 0;
	BeginBatchDraw();
	while (1)
	{
		putimage(0, 0, &im_bk);
		putimagePng(x, HEIGHT / 2, &img[i]);
		Sleep(60);
		x = x + speed;

		if (x<0||x>WIDTH-100) {
			speed = -speed;
			if (x < 0) {
				i = 4;
				direct = 1;
			}
			if (x > WIDTH-100){
				i = 0;
				direct = 0;
			}
		}
		i++;
		if (i == 4 && direct == 0)i = 0;
		if (i == 8 && direct == 1)i = 4;
		FlushBatchDraw();
	}

	_getch();
	return 0;
}

