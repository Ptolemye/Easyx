﻿#include <iostream>
#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"
#include<list>
#define WIN_WIDTH	480
#define	WIN_HEIGHT	700
using namespace std;
class bullet1 {
public:
    int x;
    int y;
	IMAGE im_bullet1;
	int wide;
	int height;
	bullet1();
    bullet1(int x, int y) {
		this->x = x;
		this->y = y;
		loadimage(&im_bullet1, _T("bullet1.png"));
    }
    void draw()
    {
		putimagePng(x,y,&im_bullet1);
    }
    void update()
    {
		y += 8;
    }
};

class bullet2 {
public:
    int x;
    int y;
	IMAGE im_bullet2;
	int wide;
	int height;
	bullet2();
	bullet2(int x, int y) {
		this->x = x;
		this->y = y;
		loadimage(&im_bullet2, _T("bullet2.png"));
	}
    void draw()
    {
		putimagePng(x, y, &im_bullet2);
    }
    void update()
    {
		y -= 6;
    }
};
list<bullet1>enemy_bullets;
list<bullet2>my_bullets;
class Enemy {
public:
	int x;
	int y;
	int direct;
	int wide;
	int height;
	bool is_killed=false;
	bool is_exploded = false;
	int explode_count=1;
	IMAGE im_enemy;
	DWORD t1 = GetTickCount();
	DWORD T1 = GetTickCount();
	DWORD t2, T2;
	Enemy();
	Enemy(int x, int y)
	{
		this->x = x;
		this->y = y;
		loadimage(&im_enemy, _T("enemy1.png"));
		wide = im_enemy.getwidth();
		height = im_enemy.getheight();
	}
	void draw()
	{
		IMAGE img[5];
		TCHAR filename[20];
		for (int j = 1; j < 5; j++)
		{
			swprintf_s(filename, _T("enemy1_down%d.png"), j);
			loadimage(&img[j], filename);
		}
		if(!is_killed)putimagePng(x, y, &im_enemy);
		else if (!is_exploded) {
			putimagePng(x, y, &img[explode_count]);
			explode_count++;
			if (explode_count == 5)is_exploded = true;
		}
	}
	void update()
	{
		t2 = GetTickCount();
		T2 = GetTickCount();
		if (t2 - t1 > 1000) {
			direct = rand() % 2;
			t1 = t2;
		}
		if (direct == 1) {
			x++;
		}
		if (direct == 0) {
			x--;
		}
		if (T2 - T1 > 700&&!is_killed) {
			enemy_bullets.push_back(bullet1(x+wide/2, y+height/2));
			T1 = T2;
		}
		y += 3;
	}
};
list<Enemy>Enemylist;
class Player {
public:
	int x;
	int y;
	int wide;
	int height;
	int HP = 10;
	int explode_count = 1;
	IMAGE im_player;
	Player();
	Player(int x, int y)
	{
		this->x = x;
		this->y = y;
		//loadimage(&im_player, _T("me1.png"));
	}
	void draw()
	{
		IMAGE img[5];
		TCHAR filename[20];
		for (int j = 1; j < 5; j++)
		{
			swprintf_s(filename, _T("me_destroy_%d.png"), j);
			loadimage(&img[j], filename);
		}
		if(HP>0)putimagePng(x, y, &im_player);
		if (HP <= 0 && explode_count != 4) {
			static DWORD t1 = GetTickCount();
			DWORD t2 = GetTickCount();
			putimagePng(x, y, &img[explode_count]);
			if (t2 - t1 >= 100) {
				explode_count++;
				t1 = t2;
			}
		}
	}
	void update()
	{
		if (_kbhit()) {
			if (GetAsyncKeyState(VK_UP) && y >= 8)     //Up
				y -= 5;
			else if (GetAsyncKeyState(VK_DOWN) && y < WIN_HEIGHT - 18) {   //Down
				y += 5;
				if (y > WIN_HEIGHT - 18)y = WIN_HEIGHT - 20;
			}
			else if (GetAsyncKeyState(VK_LEFT) && x >= 6)   //Left
				x -= 5;
			else if (GetAsyncKeyState(VK_RIGHT) && x < WIN_WIDTH - 32) { //Right
				x += 5;
				if (x > WIN_WIDTH - 32)x = WIN_WIDTH - 36;
			}
		}
	}
	void life_print()
	{
		settextstyle(20, 0, TEXT("黑体"));
		setbkmode(TRANSPARENT);
		char num[20];
		sprintf_s(num, "%d", HP);
		/*	outtextxy(100, 100, num);*/
		outtextxy(30, 30, TEXT("HP"));
		setfillcolor(RED);
		fillrectangle(80, 30, 80 + 10 * HP, 50);
	}
};
Player player(200, 600);
void lose_print()
{
	if (player.HP<=0) {
		settextstyle(40, 0, TEXT("微软雅黑"));
		setbkmode(TRANSPARENT);
		outtextxy(200, 400, TEXT("LOST"));
	}
}
void update_withoutinput() {
	static DWORD t1 = GetTickCount();
	static DWORD tt1 = GetTickCount();
	DWORD t2,tt2;
	t2 = GetTickCount();
	tt2 = GetTickCount();
	if (t2 - t1 >= 1000) {
		Enemylist.push_back(Enemy(rand() % (WIN_WIDTH - 50), 0));
		t1 = t2;
	}
	if (tt2 - tt1 >= 500&&player.HP>0) {
		my_bullets.push_back(bullet2(player.x+player.wide/2,player.y));
		tt1 = tt2;
	}
	for (auto& p : Enemylist) {
		p.update();
	}
	list<bullet1>::iterator t = enemy_bullets.begin();
	for (; t != enemy_bullets.end();) {
		(*t).update();
		if ((*t).y > WIN_HEIGHT) {
			enemy_bullets.erase(t++);
		}
		else {
			++t;
		}
	}
	auto p1 = my_bullets.begin();
	auto  p2= Enemylist.begin();
	int temp = 0;
	while(p1!=my_bullets.end()){
		while (p2 != Enemylist.end()) {
			temp = 0;
			if (!p2->is_killed&&p1->x >= p2->x && p1->x <= (p2->x + p2->wide) &&
				p1->y >= p2->y && p1->y <= (p2->y + p2->height))
			{
				p2->is_killed = true;
				my_bullets.erase(p1++);
				p2++;
				temp = 1;
				break;
			}
			else p2++;
		}
		if(!temp)p1++;
		p2 = Enemylist.begin();
	}
	p1 = my_bullets.begin();
	while (p1 != my_bullets.end()) {
		if (p1->y < 0) {
			my_bullets.erase(p1++);
		}
		else p1++;
	}
	p2 = Enemylist.begin();
	while (p2 != Enemylist.end()){
		if (p2->is_exploded||p2->y>WIN_HEIGHT)Enemylist.erase(p2++);
		else p2++;
	}
	t = enemy_bullets.begin();
	while (t!=enemy_bullets.end()) {
		if (t->x>=player.x&&t->x<=player.x+player.wide&&
			t->y >= player.y && t->y <= player.y + player.height && player.HP > 0){
				enemy_bullets.erase(t++);
				player.HP--;
		}
		else t++;
	}
	for (auto& p : my_bullets ) {
		p.update();
	}
	player.update();
}
void show()
{
	player.draw();
	player.life_print();
	lose_print();
	for (auto& p : Enemylist) {
		p.draw();
	}
	for (auto& p : enemy_bullets) {
		p.draw();
	}
	for (auto& p : my_bullets) {
		p.draw();
	}
}
int main()
{
	IMAGE im_bk;
	initgraph(WIN_WIDTH, WIN_HEIGHT);
	loadimage(&im_bk, _T("background.png"));
	loadimage(&(player.im_player), _T("me1.png"));
	player.height = player.im_player.getheight();
	player.wide = player.im_player.getwidth();
	int wide = 0;
	BeginBatchDraw();
	while (1) {
		putimage(0, wide, &im_bk);
		putimage(0, wide - 700, &im_bk);
		wide += 3;
		if (wide > 700)wide = 0;
		update_withoutinput();
		show();
		Sleep(20);
		FlushBatchDraw();
	}
}


