﻿
#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"
#include<ctime>
#include<queue>
#include<list>
#include<math.h>
#define WIDTH  800
#define HEIGHT 800
#pragma comment(lib,"Winmm.lib")
using namespace std;

int g = 1,dx_2;
IMAGE bk[10];
IMAGE im_land, im_star,im_enemy[5];
bool win = false;
class star {
public:
	int x;
	int y;
	star();
	star(int x, int y)
	{
		this->x = x;
		this->y = y;
	}
	void draw() {
		putimagePng(x, y, &im_star);
	}
	void update()
	{
		x -= 10;
	}
};
list<star>stars;
class enemy {
public:
	int x;
	int y;
	int i = 0;
	enemy();
	enemy(int x, int y)
	{
		this->x = x;
		this->y = y;
	}
	void draw() {
		putimagePng(x, y, &im_enemy[i]);
		i = (i + 1) % 5;
	}
	void update()
	{
		x -= 10;
	}
};
list<enemy>enemies;
class stage {
public:
	int x;
	int y;
	int wide;//整数，最短100，最长300
	stage();
	stage(int y) {
		this->x = 800;
		this->y = y;
		wide = 2 + rand() % 2;
	}
	void draw()
	{
		for (int i = 0; i < wide; i++)
		{
			putimage(x+i * 100, y, &im_land);
		}
	}
	void update()
	{
		x -= 10;
	}
};
list<stage> stages;
class Player {
public:
	int x;
	int y;
	int vy;
	int score = 0;
	bool alive = true;
	IMAGE im_player[8];
	IMAGE im_jump;
	bool is_run = true;
	Player();
	Player(int x,int y)
	{
		this->x = x;
		this->y = y;
	}
	void draw()
	{
		static int i=0;
		if (i > 7) i = 0;
		if (is_run)
			putimagePng(WIDTH / 4, y, &im_player[i]);
		else
			putimagePng(WIDTH / 4, y, &im_jump);

		i++;
	}
	void update()
	{
		//static bool is_jump = false;
		if (_kbhit())
		{
			char input = _getch();
			if (input == ' '&&is_run)
			{
				vy = -17;
				is_run = false;
			}
		}
		vy = vy + g;
		y = y + vy;
	}
	void score_draw()
	{
		char t[20];
		sprintf_s(t, "% d", score);
		setbkmode(TRANSPARENT);
		settextstyle(30, 0, _T("黑体"));
		outtextxy(10, 10, t);
	}
};
Player player(WIDTH / 4, HEIGHT * 2 / 3);
void bk_draw()
{
	static int wide = 0;
	static int i = 1;
	putimage(wide,0,&bk[i]);
	if(i<9)putimage(wide+2000, 0, &bk[i+1]);
	wide -= 10;
	if (i == 9 && wide <= -1200) {
		wide = -1200;
		win = true;
	}
	else if (wide <= -1200) {
		i++;
		wide = 0;
	}
	putimagePng(50, 10, &im_star);
}
void update()
{
	if(player.alive&&!win)player.update();
	if (!win) {
		for (auto& p : stages)
		{
			p.update();
		}
	}
	if (!win) {
		for (auto& p : stars)
		{
			p.update();
		}
	}
	if (!win) {
		for (auto& p : enemies)
		{
			p.update();
		}
	}
	//平台刷新
	int gap = 50 + rand() % 300;
	list<stage>::iterator it = stages.end();
	it--;
	if ((it->x) + 100 * (it->wide) < 800 - gap) {
		int deep = it->y + 100;
		int y = min(600, deep - rand() % 200);
		y = max(y, 300);
		stages.push_back(stage(y));
		if (rand() % 2 == 0) {
			stars.push_back(star(800 + rand() % 100, y - 45));
		}
		else if (rand() % 4== 0) {
			enemies.push_back(enemy(800 + rand() % 100, y - 80));
		}
	}
	//平台检测
	for (auto& p : stages)
	{
		if (player.x > p.x - 40 && player.x +40 < p.x + p.wide * 100 && player.y + 100 >= p.y && player.y < p.y) {
			player.vy = 0;
			player.y = p.y - 100;
			player.is_run = true;
		}
	}
	if (player.vy != 0)player.is_run = false;
	//平台删除
	it = stages.begin();
	while (it != stages.end()) {
		if ((it->x + it->wide * 100) < 0)stages.erase(it++);
		else it++;
	}
	//星星拾取
	list<star>::iterator t1 = stars.begin();
	while (t1 != stars.end()) {
		if (player.x + 80 > t1->x && player.x<t1->x+40 && player.y + 100>t1->y && player.y < t1->y&&player.alive) {
			stars.erase(t1++);
			player.score++;
			mciSendString(_T("close music1"), NULL, 0, NULL);
			mciSendString(_T("open getstar.mp3 alias music1"), NULL, 0, NULL);
			mciSendString(_T("play music1"), NULL, 0, NULL);
		}
		else t1++;
	}
	//怪物碰撞
	list<enemy>::iterator t2 = enemies.begin();
	while (t2 != enemies.end()) {
		if (player.x + 80 > t2->x && player.x<t2->x + 40 && player.y + 60>t2->y && player.y < t2->y&&player.alive) {
			enemies.erase(t2++);
			player.alive=false;
			mciSendString(_T("close music1"), NULL, 0, NULL);
			mciSendString(_T("open b.mp3 alias music1"), NULL, 0, NULL);
			mciSendString(_T("play music1"), NULL, 0, NULL);
		}
		else t2++;
	}
	//掉落检查
	if (player.y > 800)player.alive = false;
}
void show() {
	if (!player.alive) {
		setbkmode(TRANSPARENT);
		settextstyle(70, 0, _T("黑体"));
		outtextxy(300, 300, _T("LOST"));
	}
	if (win) {
		setbkmode(TRANSPARENT);
		settextstyle(70, 0, _T("黑体"));
		outtextxy(300, 300, _T("WIN"));
	}
	if(player.alive)player.draw();
	for (auto& p : stages)
	{
		p.draw();
	}
	for (auto& p : stars)
	{
		p.draw();
	}
	for (auto& p : enemies)
	{
		p.draw();
	}
	player.score_draw(); 
}
int main()
{
	srand(time(0));
	initgraph(WIDTH, HEIGHT);
	TCHAR filename[25];
	for (int i = 0; i < 5; i++)
	{
		_stprintf_s(filename, _T("bat%d.png"), i);
		loadimage(&im_enemy[i], filename);
	}
	for (int i = 0; i < 8; i++)
	{
		_stprintf_s(filename, _T("runright%d.png"), i);
		loadimage(&player.im_player[i], filename);
	}
	for (int i = 1; i < 10; i++)
	{
		_stprintf_s(filename, _T("landscape%d.png"), i);
		loadimage(&bk[i], filename);
	}
	loadimage(&im_land, _T("land.png"));
	loadimage(&player.im_jump, _T("jumpright.png"));
	loadimage(&im_star, _T("star.png"));
	stages.push_back(stage(HEIGHT * 2 / 3+100));
	stages.begin()->wide = 8;
	stages.begin()->x = 0;
	BeginBatchDraw();
	while (1)
	{
		bk_draw();
		update();
		show();
		Sleep(60);
		FlushBatchDraw();
	}

	_getch();
	return 0;
}


